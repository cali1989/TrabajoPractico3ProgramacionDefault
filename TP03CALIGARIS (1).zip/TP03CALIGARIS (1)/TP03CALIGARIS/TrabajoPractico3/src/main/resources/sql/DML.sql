-- Active: 1718839475313@@127.0.0.1@3306@turismo


use turismo;

INSERT INTO Destinos (nombre, pais, ciudad, descripcion, activo) VALUES
    ('Machu Picchu', 'Perú', 'Cusco', 'Sitio arqueológico inca en los Andes peruanos', true),
    ('Gran Cañón', 'Estados Unidos', 'Arizona', 'Inmenso cañón excavado por el río Colorado', true),
    ('Chichen Itza', 'México', 'Yucatán', 'Ruinas mayas en la península de Yucatán', true),
    ('Dubái', 'Emiratos Árabes Unidos', 'Dubái', 'Ciudad conocida por sus rascacielos y lujo', true),
    ('Bali', 'Indonesia', 'Bali', 'Isla famosa por sus playas, templos y cultura', true),
    ('Santorini', 'Grecia', 'Santorini', 'Isla griega con pueblos blancos y azules', true),
    ('Venecia', 'Italia', 'Venecia', 'Ciudad construida sobre canales con góndolas', true),
    ('Sídney', 'Australia', 'Sídney', 'Ciudad conocida por su arquitectura y playas', true),
    ('Río de Janeiro', 'Brasil', 'Río de Janeiro', 'Ciudad famosa por el Corcovado y el Carnaval', true),
    ('Islandia', 'Islandia', 'Reikiavik', 'Conocida por sus geyseres, volcanes y auroras boreales', true);

select * from Destinos;

INSERT INTO Paquetes (nombre, descripcion, precio, idDestino, activo) VALUES
    ('Paquete Machu Picchu', 'Visita al sitio arqueológico de Machu Picchu', 1500.00, 1, true),
    ('Paquete Gran Cañón', 'Excursión al imponente Gran Cañón', 1200.00, 2, true),
    ('Paquete Chichen Itza', 'Exploración de las ruinas mayas de Chichen Itza', 1800.00, 3, true),
    ('Paquete Dubái', 'Descubre la ciudad de lujo y rascacielos de Dubái', 2500.00, 4, true),
    ('Paquete Bali', 'Viaje a la isla de Bali con sus playas y cultura', 1900.00, 5, true),
    ('Paquete Santorini', 'Visita a la hermosa isla de Santorini', 2000.00, 6, true),
    ('Paquete Venecia', 'Paseo en góndola por los canales de Venecia', 2200.00, 7, true),
    ('Paquete Sídney', 'Descubre la arquitectura y playas de Sídney', 2300.00, 8, true),
    ('Paquete Río de Janeiro', 'Disfruta del Corcovado y el Carnaval en Río', 2100.00, 9, true),
    ('Paquete Islandia', 'Explora los geyseres, volcanes y auroras boreales de Islandia', 2400.00, 10, true);

select * from Paquetes;

INSERT  INTO Clientes (nombre, apellido, email, telefono, activo) VALUES
    ('Juan', 'Pérez', 'juanperez@example.com', '+1 555-1234', true),
    ('María', 'Gómez', 'mariagomez@example.com', '+1 555-5678', true),
    ('Luis', 'Hernández', 'luishernandez@example.com', '+1 555-9012', true),
    ('Ana', 'Rodríguez', 'anarodriguez@example.com', '+1 555-3456', true),
    ('Pedro', 'Martínez', 'pedromartinez@example.com', '+1 555-7890', true),
    ('Laura', 'Pérez', 'lauraperez@example.com', '+1 555-2345', true),
    ('Carlos', 'García', 'carlosgarcia@example.com', '+1 555-6789', true),
    ('Sofía', 'Fernández', 'sofiafernandez@example.com', '+1 555-0123', true),
    ('Javier', 'González', 'javiergonzalez@example.com', '+1 555-4567', true),
    ('Valeria', 'Torres', 'valeriatores@example.com', '+1 555-8901', true);

 select * from Clientes;   

INSERT INTO Reservas (idCliente, idPaquete, fechaInicio, fechaFin, numPersonas, precio, activo) VALUES
    (1, 1, '2024-08-01', '2024-08-07', 2, 3000.00, true),
    (2, 2, '2024-09-15', '2024-09-22', 4, 4800.00, true),
    (3, 3, '2024-10-10', '2024-10-17', 3, 5400.00, true),
    (4, 4, '2024-11-20', '2024-11-27', 2, 5000.00, true),
    (5, 5, '2024-12-01', '2024-12-08', 3, 5700.00, true),
    (6, 6, '2024-01-05', '2024-01-12', 2, 4000.00, true),
    (7, 7, '2024-02-15', '2024-02-22', 4, 8800.00, true),
    (8, 8, '2024-03-01', '2024-03-08', 3, 6900.00, true),
    (9, 9, '2024-04-20', '2024-04-27', 2, 4200.00, true),
    (10, 10, '2024-05-10', '2024-05-17', 3, 7200.00, true);

select * from Reservas;