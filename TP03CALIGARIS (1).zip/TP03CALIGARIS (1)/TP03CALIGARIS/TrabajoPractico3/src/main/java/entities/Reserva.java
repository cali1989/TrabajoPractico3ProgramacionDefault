package entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Reserva {

    private int idCliente;
    private int idPaquete;
    private String fechaInicio;
    private String fechaFin;
    private int numPersonas;
    private double precio;

}
