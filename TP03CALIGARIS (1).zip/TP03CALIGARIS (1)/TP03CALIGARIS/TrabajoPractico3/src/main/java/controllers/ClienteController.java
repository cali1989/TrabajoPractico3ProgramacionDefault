
package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import entities.Cliente;
import repositories.ClienteRepository;

@Controller
public class ClienteController {
   
    private String mensaje = "Ingrese un nuevo cliente!";
    private ClienteRepository clienteRepository= new ClienteRepository();

    @GetMapping("/clientes")
    public String getClientes(Model model, @RequestParam(name="buscar",
     defaultValue = "") String buscar) {
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("cliente", new Cliente());
        model.addAttribute("clientes", clienteRepository.getAll());
        model.addAttribute("clientesFiltrados", clienteRepository.getByEmail(buscar));
        return "clientes";
    }

    @PostMapping("/clientesSave")
    public String clientesSave(@ModelAttribute Cliente cliente) {
        clienteRepository.save(cliente);
        if (cliente.getId() > 0) {
            mensaje = "Se guardó el cliente con ID: " + cliente.getId();
        } else {
            mensaje = "¡Error! No se pudo guardar el cliente.";
        }
        return "redirect:/clientes";
    }
}


