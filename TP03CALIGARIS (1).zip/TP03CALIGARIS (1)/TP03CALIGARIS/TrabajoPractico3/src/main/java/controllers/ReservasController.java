package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import entities.Reserva;
import repositories.ReservaRepository;

@Controller
public class ReservasController {

    private String mensaje = "Ingrese una nueva reserva!";
    private ReservaRepository reservaRepository = new ReservaRepository();

    @GetMapping("/reservas")
    public String getReservas(Model model, @RequestParam(name = "buscar", defaultValue = "") String buscar) {
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("reserva", new Reserva());
        model.addAttribute("reservas", reservaRepository.getAll());

        if (buscar != null && !buscar.isEmpty()) {
            try {
                int idPaquete = Integer.parseInt(buscar);
                model.addAttribute("reservasFiltradas", reservaRepository
                        .getReservasByPaquete(idPaquete));
            } catch (NumberFormatException e) {

                model.addAttribute("reservasFiltradas", reservaRepository.getAll());
            }
        } else {
            model.addAttribute("reservasFiltradas", reservaRepository.getAll());
        }
        return "reservas";
    }

    @PostMapping("/reservasSave")
    public String reservasSave(@ModelAttribute Reserva reserva) {
        reservaRepository.save(reserva);
        if (reserva.getIdCliente() > 0 && reserva.getIdPaquete() > 0) {
            mensaje = "Se guardó la reserva con ID: " + reserva.getIdCliente()
                    + " para el paquete " + reserva.getIdPaquete();
        } else {
            mensaje = "¡Error! No se pudo guardar la reserva.";
        }
        return "redirect:/reservas";
    }
}
