package controllers;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import entities.Destino;
import repositories.DestinoRepository;

@Controller
public class DestinosController {
   
    private String mensaje = "Ingrese un nuevo destino!";
    private DestinoRepository destinoRepository= new DestinoRepository();

    @GetMapping("/destinos")
    public String getDestinos(Model model, @RequestParam(name="buscar",
     defaultValue = "") String buscar) {
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("destino", new Destino());
        model.addAttribute("destinos", destinoRepository.getAll());
        model.addAttribute("destinosFiltrados", destinoRepository
        .getDestinosByPais(buscar));
        return "destinos";
    }

    @PostMapping("/destinosSave")
    public String destinosSave(@ModelAttribute Destino destino) {
        destinoRepository.save(destino);
        if (destino.getId() > 0) {
            mensaje = "Se guardó el destino con ID: " + destino.getId();
        } else {
            mensaje = "¡Error! No se pudo guardar el destino.";
        }
        return "redirect:/destinos";
    }
}


