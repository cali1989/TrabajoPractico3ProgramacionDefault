package controllers;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import entities.Paquete;
import repositories.PaqueteRepository;

@Controller
public class PaquetesController {
   
    private String mensaje = "Ingrese un nuevo paquete!";
    private PaqueteRepository paqueteRepository= new PaqueteRepository();

    @GetMapping("/paquetes")
    public String getPaquetes(Model model, @RequestParam(name="buscar",
     defaultValue = "") String buscar) {
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("paquete", new Paquete());
        model.addAttribute("paquetes", paqueteRepository.getAll());
        
        if (buscar != null && !buscar.isEmpty()) {
            try {
                int idDestino = Integer.parseInt(buscar);
                model.addAttribute("paquetesFiltrados", paqueteRepository.getPaquetesByDestino(idDestino));
            } catch (NumberFormatException e) {
                
                model.addAttribute("paquetesFiltrados", paqueteRepository.getAll());
            }
        } else {
            model.addAttribute("paquetesFiltrados", paqueteRepository.getAll());
        }
        return "paquetes";
    }

    @PostMapping("/paquetesSave")
    public String paquetesSave(@ModelAttribute Paquete paquete) {
        paqueteRepository.save(paquete);
        if (paquete.getId() > 0) {
            mensaje = "Se guardó el paquete con ID: " + paquete.getId();
        } else {
            mensaje = "¡Error! No se pudo guardar el paquete.";
        }
        return "redirect:/paquetes";
    }
}

