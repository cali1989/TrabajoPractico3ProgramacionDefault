
package test;

import entities.Cliente;
import entities.Destino;
import entities.Paquete;
import entities.Reserva;
import repositories.ClienteRepository;
import repositories.DestinoRepository;
import repositories.PaqueteRepository;
import repositories.ReservaRepository;

public class TestRepository {

        public static void main(String[] args) {

                ClienteRepository clienteRepository = new ClienteRepository();

                System.out.println("--------------------------------------");
                System.out.println("-- Test Cliente Repository --");
                System.out.println("--------------------------------------");
                System.out.println("-- Método .save() --");

                

                Cliente cliente= new Cliente(
                                0,
                                "Pedro",
                                "Fernandez",
                                "Pedro@Fernandez455.com",
                                "555-1235");
                clienteRepository.save(cliente);
                System.out.println(cliente);

                

                System.out.println("-- Método .getById --");
                System.out.println(clienteRepository.getById(1));

                System.out.println("-- Método remove() --");
                clienteRepository.remove(clienteRepository.getById(11));

                System.out.println("-- Método .getAll() --");
                clienteRepository.getAll().forEach(System.out::println);

                DestinoRepository destinoRepository = new DestinoRepository();

                System.out.println("--------------------------------------");
                System.out.println("-- Test Destino Repository --");
                System.out.println("--------------------------------------");
                System.out.println("-- Método .save() --");

                Destino destino = new Destino(
                                0,
                                "Playa del Carmen",
                                "Mexico",
                                "Quintana Roo",
                                "Hermosas playas de arena blanca");
                destinoRepository.save(destino);
                System.out.println(destino);

                System.out.println("-- Método .getById --");
                System.out.println(destinoRepository.getById(1));

                System.out.println("-- Método remove() --");
                destinoRepository.remove(destinoRepository.getById(11));

                System.out.println("-- Método .getAll() --");
                destinoRepository.getAll().forEach(System.out::println);
                System.out.println("-- Método getDestinosByPais --");
                destinoRepository.getDestinosByPais("Mexico")
                .forEach(System.out::println);

                PaqueteRepository paqueteRepository = new PaqueteRepository();

                System.out.println("--------------------------------------");
                System.out.println("-- Test Paquete Repository --");
                System.out.println("--------------------------------------");
                System.out.println("-- Método .save() --");

                Paquete paquete = new Paquete(
                                0,
                                "Paquete A",
                                "Descripción del Paquete A",
                                250.50,
                                1);
                paqueteRepository.save(paquete);
                System.out.println(paquete);

                System.out.println("-- Método .getById --");
                System.out.println(paqueteRepository.getById(1));

                System.out.println("-- Método remove() --");
                paqueteRepository.remove(paqueteRepository.getById(11));

                System.out.println("-- Método .getAll() --");
                paqueteRepository.getAll().forEach(System.out::println);

                System.out.println("-- Método getPaquetesByDestino --");
                paqueteRepository.getPaquetesByDestino(1)
                                .forEach(System.out::println);

                ReservaRepository reservaRepository = new ReservaRepository();

                System.out.println("--------------------------------------");
                System.out.println("-- Test Reserva Repository --");
                System.out.println("--------------------------------------");
                System.out.println("-- Método .save() --");

                Reserva reserva = new Reserva(10,
                 10, 
                 "2024-05-10",
                 "2024-05-17",
                  3, 
                  7200.00);
                reservaRepository.save(reserva);
                System.out.println(reserva);

                System.out.println("-- Método .getById --");
                System.out.println(reservaRepository.getById(1));

                System.out.println("-- Método remove() --");
                reservaRepository.remove(reservaRepository.getById(11));

                System.out.println("-- Método .getAll() --");
                reservaRepository.getAll().forEach(System.out::println);

                System.out.println("-- Método getReservasByPaquete --");
                reservaRepository.getReservasByPaquete(1)
                                .forEach(System.out::println);
        }
}
