package repositories;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import connectors.Connector;
import entities.Reserva;

public class ReservaRepository {
    private java.sql.Connection conn = Connector.getConnection();
    private static final DecimalFormat df = new DecimalFormat("0.00");

    public void save(Reserva reserva) {
        if (reserva == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO Reservas (idCliente, idPaquete, fechaInicio, fechaFin, numPersonas, precio) VALUES (?, ?, ?, ?, ?, ?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, reserva.getIdCliente());
            ps.setInt(2, reserva.getIdPaquete());
            ps.setDate(3, Date.valueOf(reserva.getFechaInicio()));
            ps.setDate(4, Date.valueOf(reserva.getFechaFin()));
            ps.setInt(5, reserva.getNumPersonas());
            ps.setString(6, df.format(reserva.getPrecio()));
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    reserva.setIdCliente(0);
                    reserva.setIdPaquete(0);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Reserva reserva) {
        if (reserva == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM Reservas WHERE id = ?")) {
            ps.setInt(1, reserva.getIdCliente());
            ps.setInt(1, reserva.getIdPaquete());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Reserva> getAll() {
        List<Reserva> list = new ArrayList();
        try (ResultSet rs = conn
                .createStatement()
                .executeQuery("SELECT * FROM Reservas")) {
            while (rs.next()) {
                list.add(new Reserva(
                        rs.getInt("idCliente"),
                        rs.getInt("idPaquete"),
                        rs.getString("fechaInicio"),
                        rs.getString("fechaFin"),
                        rs.getInt("numPersonas"),
                        rs.getDouble("precio")));
                   
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Reserva getById(int id) {
        return getAll()
                .stream()
                .filter(reserva -> reserva.getIdCliente() == id)
                .filter(reserva -> reserva.getIdPaquete() == id)
                .findFirst()
                .orElse(new Reserva());
    }

    public List<Reserva> getReservasByPaquete(int idPaquete) {
        return getAll()
                .stream()
                .filter(reserva -> reserva.getIdPaquete() == idPaquete)
                .collect(Collectors.toList());
    }
}