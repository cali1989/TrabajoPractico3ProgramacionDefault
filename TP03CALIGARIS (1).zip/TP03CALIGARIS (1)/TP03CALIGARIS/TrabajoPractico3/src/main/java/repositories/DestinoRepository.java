package repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import connectors.Connector;
import entities.Destino;

public class DestinoRepository {
    
 private Connection conn = Connector.getConnection();

    public void save(Destino destino) {
        if (destino == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO Destinos (nombre, pais, ciudad, descripcion) VALUES (?, ?, ?, ?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, destino.getNombre());
            ps.setString(2, destino.getPais());
            ps.setString(3, destino.getCiudad());
            ps.setString(4, destino.getDescripcion());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                destino.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Destino destino){
        if(destino == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM Destinos WHERE id = ?")) {
            ps.setInt(1, destino.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Destino> getAll() {
        List<Destino> list = new ArrayList();
        try (ResultSet rs = conn
                .createStatement()
                .executeQuery("SELECT * FROM Destinos")) {
            while (rs.next()) {
                list.add(new Destino(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("pais"),
                        rs.getString("ciudad"),
                        rs.getString("descripcion")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Destino getById(int id){
        return getAll()
                .stream()
                .filter(destino -> destino.getId() == id)
                .findFirst()
                .orElse(new Destino());
    }

    public List<Destino> getDestinosByPais(String pais){
        if(pais == null) return new ArrayList();
        return getAll()
                .stream()
                .filter(destino -> destino
                        .getPais()
                        .equalsIgnoreCase(pais))
                .collect(Collectors.toList());
    }
}
