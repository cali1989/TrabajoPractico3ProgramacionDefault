package TrabajoPracticoNoche3.TrabajoPractico3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoPractico3Application {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoPractico3Application.class, args);
	}

}
